Placeholder Lambda package for terraform test: the mocked provider never uploads it.
